 #include <GSM3MobileServerProvider.h>
 
 GSM3MobileServerProvider* theGSM3MobileServerProvider;
 
 